<header>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Style for form */ 
        form {
        margin: 0 auto;
        width: 50%;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
        }

        input[type="email"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        }
        
    </style>

</head>

<form action="forgot-password.php" method="post">   
    <input type="email" name="email" placeholder="Enter your email address" required>   
    <button type="submit" >Reset Password</button> 
</form>


<?php

session_start();

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if(isset($_SESSION['loggedInStatus']) && $_SESSION['loggedInStatus'] === True){
    header("location: index.php");
}


$email;

if($_SERVER['REQUEST_METHOD'] === 'POST'){

    $email = $_POST['email'];  // gets the user to enter their email 

$dbcreds = new mysqli('localhost', 'root', '', 'webdb'); // after email is entered we connect to the database containing all data

// if email is found we fetch it from database and procceed to the next page 
if($stmt = $dbcreds -> prepare("SELECT `email` FROM `users` WHERE BINARY `email` = ? LIMIT 1"))
        $stmt -> bind_param("s", $email);
        $stmt -> execute();

        if($stmt -> fetch()) {
            $_SESSION["email"] = $email;
            header("Location: tokenGen.php");    // this take us to next page if email is fetched succesfully
        } 
  
     $stmt -> close();
 }


?>
