<?php

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function valid_username($username){
    $allowed_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_";

    return ctype_alnum(str_replace('_',' ', $username));
}


function sanitize_password($password) {

    // Define the allowed characters for the password
    $allowed_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_!@#$^&()";

    // Check if the password contains only allowed characters
    if (preg_match('/^[ '.$allowed_chars.']*$/u', $password)) {

    // Password is valid, return the original password
        return $password;
    } else {
        
     // Password contains unauthorized characters, deny it
        return false;
    }
}


?>