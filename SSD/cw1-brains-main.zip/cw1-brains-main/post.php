<!DOCTYPE html> 
<html> 
<head> 
    <title>5218COMP GROUP COURSEWORK</title> 
    <link rel="stylesheet" type="text/css" href="style.css"> 
    <style> 
        /* Style for Post Contents */
        body { 
            font-family: 'Arial', sans-serif; 
            background-color: #f5f5f5; 
            text-align: center; 
            margin: 50px; 
        } 

        h1 { 
            color: #007BFF; 
        } 

        .post { 
            max-width: 600px; 
            margin: 0 auto;
            background-color: #fff; 
            padding: 20px; 
            border-radius: 10px; 
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); 
        } 

        label { 
            display: block; 
            margin-bottom: 10px; 
            font-weight: bold; 
            color: #333; 
        } 

        textarea { 
            width: 100%; 
            height: 100px; 
            resize: vertical; 
            margin-bottom: 15px; 
        } 

        input[type="submit"] { 
            background-color: #007BFF; 
            color: #fff; 
            border: none; 
            padding: 10px 20px; 
            border-radius: 5px; 
            cursor: pointer; 
        } 

        .content-box { 
            max-width: 600px; 
            margin: 20px auto; 
            background-color: #fff; 
            padding: 20px; 
            border-radius: 10px; 
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); 
        } 
        
        .content-box h2 { 
            color: #007BFF; 
        } 

        .content-box p { 
            color: #555; 
        } 
    </style> 
</head> 
<body> 

<div class="post"> 
    <h1>5218COMP GROUP COURSEWORK</h1> 

    <form method="POST" action="post.php"> 
        <label for="Title">Title:</label> 
        <textarea name="Title" placeholder="Enter your Title"></textarea> 
        <label for="Content">Content:</label> 
        <textarea name="Content" placeholder="Enter your Content"></textarea> 
        <input type="submit" value="Post"> 
        <a href="index.php" class="Index-button">Index Page</a> 
    </form> 
</div> 


<?php 

// Sets up an HTTP-only cookie and Starts a new session  
session_start(); 

// assigns a unique CSRF token for every user session
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
setcookie("my_session_cookie", session_id(), 0, "/", "", true, true); 

// Sets the loggedInStatus to not be true
if (!isset($_SESSION['loggedInStatus']) || $_SESSION['loggedInStatus'] !== true) {
    $username = "Guest-" . rand(1, 999); // generates a random number for the guest as their username
    $userid = null; 
} else {
    // logs the user in and displays their user name
    $username = $_SESSION['username']; 
    $userid = $_SESSION['uid'];
}

// checks if the form is submitted using post

if ($_SERVER['REQUEST_METHOD'] === "POST") { 

// retrieves the title, content and timestamp from the database
    $title = $_POST["Title"]; 
    $content = $_POST["Content"]; 
    $timestamp = date('Y-m-d H:i:s');

// establishes a connection to the database
    $dbcreds = new mysqli('localhost', 'root', '', 'webdb'); 

// checks if the query was successful, if not it displays connection failed.
    if ($dbcreds->connect_error) {
        die("Connection failed: " . $dbcreds->connect_error);
    }

//function that has been created to sanitize the input 
    function sanitize_input($dbcreds, $input) { 
        return mysqli_real_escape_string($dbcreds, htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8')); 
    } 

// sanitizes the user's input
    $title = sanitize_input($dbcreds, $_POST["Title"]); 
    $content = sanitize_input($dbcreds, $_POST["Content"]); 

    $title = htmlspecialchars(trim($_POST["Title"]), ENT_QUOTES, 'UTF-8');
    $content = htmlspecialchars(trim($_POST["Content"]), ENT_QUOTES, 'UTF-8');  

// inserts into the database
    $stmt = $dbcreds->prepare("INSERT INTO `posts` (`title`, `content`, `timestamp`, `user_name`, `user_id`) VALUES (?, ?, ?, ?, ?)"); 
    $stmt->bind_param("sssss", $title, $content, $timestamp, $username, $userid); 

    if (!$stmt->execute()) { 
        echo "Posts have not been Submitted!"; 
        exit(); 
    } else { 
        echo "Posts have been Submitted!"; 
    } 
    $stmt->close(); 
}

// gets data from database
$dbcreds = new mysqli('localhost', 'root', '', 'webdb'); 
if ($dbcreds->connect_error) {
    die("Connection failed: " . $dbcreds->connect_error);
}

if ($stmt = $dbcreds->prepare("SELECT `title`, `content`, `timestamp`, `user_name` FROM `posts`")) { 
    $stmt->execute(); 
    $results = $stmt->get_result(); 
    while ($row = $results->fetch_assoc()) { 
        echo "<div class='content-box'>"; 
        echo "<h2>" . htmlspecialchars($row["title"]) . "</h2>"; 
        echo "<p>" . htmlspecialchars($row["content"]) . "</p>"; 
        echo "<p>" . htmlspecialchars($row["timestamp"]) . "</p>"; 
        echo "<p>" . htmlspecialchars($row["user_name"]) . "</p>";
        echo "</div>"; 
    } 
    $stmt->close(); 
} 

$dbcreds->close();
?> 

</body> 
</html>
