<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Register</title>
</head>
<body>
    <div id="register-form">
        <div id="form-title">
            <h3>Register</h3>
        </div>
        <form method="post">
            <label for="email">Email: <br></label>
            <input type="text" name="email" id="email">
            <br>
            <label for="username">Username: <br></label>
            <input type="text" name="username" id="username">
            <br>
            <label for="password">Password: <br></label>
            <input type="password" name="password" id="password">
            <br>
            <label for="repeat">Confirm Password: <br></label>
            <input type="password" name="repeat" id="repeat"><br>
            <button type="submit" value="Register">Register</button>
            <a href="/cw1-brains/login.php" class="has-account-button">Already Have An Account? Login!</a>
        </form>
    </div>
</body>
</html>

<?php
     
     if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    
     // Check if the form is submitted using POST method
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Retrieving user input from the form
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_pswd = $_POST['repeat'];
     
    // Include external functions
    include 'functions.php';


    // Validate email, username, and password
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die('Email is not valid!');
    } elseif (strlen($username) > 15) {
        die('Username length is too long!');
    } elseif (!valid_username($username)) {
        die('Username is not valid! Please only use alphanumeric characters!');
    } elseif (!sanitize_password($password)){
        die('Enter only alphanumeric characters and _!@#$^&()');
    }
    elseif (strlen($password) < 8) {
        die('Password length is too short');
    } elseif ($password !== $confirm_pswd) {
        die('Provided passwords do not match!');
    }

    // Hash the password using bcrypt
    $hash = password_hash($password, PASSWORD_DEFAULT);
       
    //connection to the database
    $dbcreds = new mysqli('localhost', 'root', '', 'webdb');


    // Check if the username already exists in the database
    if ($stmt_username = $dbcreds->prepare("SELECT `username` FROM `users` WHERE `username` = ? LIMIT 1")) {
        $stmt_username->bind_param("s", $username);
        $stmt_username->execute();
        $stmt_username->store_result();

     // If the username already exists, exit with a message
        if ($stmt_username->num_rows > 0) {
            echo "Username Already Exists Please Try Again!";
            exit();
        }
        $stmt_username->close();
    }
    // Check if the email address is already registered
    if ($stmt_email = $dbcreds->prepare("SELECT `email` FROM `users` WHERE `email` = ?")) {
        $stmt_email->bind_param("s", $email);
        $stmt_email->execute();
        $stmt_email->store_result();

    // If the email is already associated with an account, exit with a message
        if ($stmt_email->num_rows > 0) {
            echo "This Email Address is already registered with an account!";
            exit();
        }
        $stmt_email->close();
    }
     // inserting the new user into the 'users' table
    if ($stmt = $dbcreds->prepare("INSERT INTO `users` (`email`, `username`, `password`) VALUES (?, ?, ?)")){
        $stmt->bind_param("sss", $email, $username, $hash);

    // If execution fails, exit with a database error message
        if (!$stmt->execute()) {
            echo "Database Error!";
            exit();
        }else {

    // Redirecting to the login page after successful registration
            header("Location: login.php");
        }
    }




}
?>

