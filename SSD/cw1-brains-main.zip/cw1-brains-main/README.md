[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/D077LSi1)
# cwk1
## SSD CWK1 Repository

# imports
First create a database under the name webdb and then import the webdb.sql file before proceeding.

Web root should be: /cw1-brains/

When connecnting to localhost, it should be as follows: localhost/cw1-brains/index.php as that is our starting page 

Reset password: it doesn't actually send an email, so for coursework purpose it displays the token. Also when you get the token be quick, as it has a time limit of a minute.
