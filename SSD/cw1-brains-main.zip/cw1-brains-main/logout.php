<?php

session_start();

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if(isset($_SESSION['user_id']))
{
    unset($_SESSION['user_id']);

}

header("Location: login.php");
die;