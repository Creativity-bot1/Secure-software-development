<?php
session_start();

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (!isset($_SESSION['loggedInStatus']) || $_SESSION['loggedInStatus'] != true) {
    header("Location: login.php");  //Check if user is logged in.
}

$username = $_SESSION['username'];

function find_pfp($username) //Find existing profile picture
{
    $filename = $username . "_profile_picture";
    $directory = "images/profile_pictures/"; //expected file name and path

    if ($handle = opendir($directory)) {
        while (false !== ($file = readdir($handle))) { //Open directory
            if ($file != "." && $file != "..") { //ignore . and .. directories to avoid leaving current working directory.
                $foundfilename = pathinfo($file, PATHINFO_FILENAME);
                if (strcasecmp($foundfilename, $filename) === 0) {
                    return $directory . $file;
                }
            }
        }
        closedir($handle);
    }

    return "images/profile_pictures/Default_profile_picture.png"; //If not found, use default profile picture
}

$image_source = find_pfp($username);

$dbcreds = new mysqli('localhost', 'root', '', 'webdb');

if ($stmt = $dbcreds->prepare("SELECT `id`, `email` FROM `users` WHERE `username` = ? LIMIT 1")) {
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($userID, $userEmail); // Get users userID and Email
    $stmt->fetch();
    $stmt->close();
} else {
    echo "Database Error! Please Try Again Later!";
}

//-------File Upload Handling-----------

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_FILES["imageToUpload"])) {
        $upload_dir = "images/profile_pictures/";
        $filename = $username . "_profile_picture." . strtolower(pathinfo($_FILES["imageToUpload"]["name"], PATHINFO_EXTENSION));
        $target_file = $upload_dir . $filename;
        $uploadSuccess = true;

        //Check File Extensions
        $allowedExtensions = ['jpg', 'jpeg', 'png'];
        $fileExtension = strtolower(pathinfo($_FILES["imageToUpload"]["name"], PATHINFO_EXTENSION));
        if (!in_array($fileExtension, $allowedExtensions)) {
            echo "Only JPG and PNG file types are allowed!";
            $uploadSuccess = false;
        }

        // Verify MIME type
        $allowedMimeTypes = ['image/jpeg', 'image/png'];
        $fileMimeType = mime_content_type($_FILES["imageToUpload"]["tmp_name"]);
        if (!in_array($fileMimeType, $allowedMimeTypes)) {
            echo "Only JPG and PNG images are allowed!";
            $uploadSuccess = false;
        }

        if ($_FILES["imageToUpload"]["size"] > 500000) {
            echo "Only Image sizes below 5kb are allowed!";
            $uploadSuccess = false;
        }

        if ($uploadSuccess) {
            // Store the old image source temporarily
            $old_image_source = $image_source;

            if (file_exists($old_image_source)) {

                if($old_image_source !== "images/profile_pictures/Default_profile_picture.png"){
                unlink($old_image_source); // Delete the existing profile picture unless it is the default one.
                }
            }

            if (move_uploaded_file($_FILES["imageToUpload"]["tmp_name"], $target_file)) {
                $image_source = $target_file; // Update $image_source with the new file path
            } else {
                echo "Error Changing Image, Please Try Again!";
                // Restore the old image source if upload fails
                $image_source = $old_image_source;
            }
        }
    }
}


//-------------------------------------
$pfp_card = <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div id="card" class="profile-card">
        <div id="profile-picture" class="profile-picture">
            <img src="$image_source" alt="Profile Picture">
        </div>
        <div id="pfp_upload" class="profile-picture-upload">
            <form action="profile.php" method="post" enctype="multipart/form-data">
                <input type="file" name="imageToUpload" id="imageToUpload">
                <input type="submit" value="Change Photo" name="submit">
            </form>
        </div>
        <div id="user-info" class="user-info">
            <h2>Username: $username</h2>
            <p>User ID: $userID</p>
            <p>Email: $userEmail</p>
        </div>
        <div id="home-button" class="home-button">
            <a href="index.php">Home</a>
        </div>
    </div>
</body>
</html>
HTML;

echo $pfp_card;

?>
