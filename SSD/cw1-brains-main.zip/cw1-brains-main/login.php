<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Style for button */
        .forgot-password-button 
        {
            display: inline-block;
            padding: 10px;
            background-color: #3498db;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 10px;
        }
    </style>
    <title>Login</title>
</head>

<body>
    <article class="grid">
    <div id="login-form">
        <div id="login-title">
            <h3>Login</h3>
        </div>
        <div id="login-boxes">
            <form method = 'post'>
                <label for="username">Username: <br></label>
                <input type="text" name="username" id="username"><br>
                <label for="password">Password: <br></label>
                <input type="password" name="password" id="password"><br>
                <button type="submit" value="Submit">Submit</button>
            </form>

            <!-- The "No account? Create one!" link -->
            <a href="/cw1-brains/register.php" class="create-account-link">No account? Create one!</a>

             <!-- The "Forgot Password" button -->
             <a href="forgot-password.php" class="forgot-password-button">Forgot Password</a>
        
            </div>
    </div>
    </article>
</body>
</html>


<?php

// Start a session and initialize the loggedInStatus to false
session_start();

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$_SESSION['loggedInStatus'] = False;

// Include external functions
include 'functions.php';

// Declaring variables for username and password
$username;
$password;

// Check if the form is submitted using POST method
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

// Retrieve username and password from the form
    $username = $_POST['username'];
    $password = $_POST['password'];

    
// Establish a connection to the database
    $dbcreds = new mysqli('localhost', 'root', '', 'webdb');

// SQL query to retrieve user credentials
    $query = "SELECT `id`, `password` FROM `users` WHERE `username` = \"$username\"";

    // Executing the query
    $result = $dbcreds -> query($query);

// Check if the query was successful and there are results
    if ($result !== false && $result->num_rows > 0) {

// Fetching the stored credentials
        $stored_credentials = $result->fetch_assoc();
        $hash = $stored_credentials['password'];

// Verifying the entered password with the hashed password
        if (password_verify($password, $hash)) {

// Set session variables upon successful logining in
            $_SESSION['loggedInStatus'] = true;
            $_SESSION['username'] = $username;
            $_SESSION['uid'] = $stored_credentials['id'];
            $result->close();

// Redirecting to the index page
            header("Location: index.php");
            exit(); 

// Display an error message if the usernamr or password is incorrect

        } else {
            echo "Username Or Password Are Incorrect!";
        }
    } else {
        echo "Username Or Password Are Incorrect!";
    }
}
?>