<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>5218COMP GROUP COURSEWORK</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            text-align: center;
            margin: 50px;
        }

        h1 {
            color: #007BFF;
        }

        a {
            text-decoration: none;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 5px;
            margin-top: 20px;
            display: inline-block;
            transition: background-color 0.3s, color 0.3s;
        }

        .welcome-message {
            margin-top: 30px;
            font-size: 24px;
            color: #333;
        }

        .username {
            color: #007BFF;
            font-weight: bold;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
        }

        .logo {
            margin-bottom: 20px;
        }

        .post-button {
            background-color: #007BFF;
            color: #fff;
        }

        .profile-button {
            background-color: #007BFF;
            color: #fff;
            margin-left: 10px;
        }

        .logout-button {
            background-color: #dc3545;
            color: #fff;
            margin-left: 10px;
        }

        .login-button {
            background-color: #28a745;
            color: #fff;
            margin-left: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <img class="logo" src="https://www.ljmu.ac.uk/-/media/ljmu/logos/ljmu_logo_banner_835.jpg" alt="Image" width="300">
        <h1>5218COMP GROUP COURSEWORK</h1>
        <div class="welcome-message">
            <h2>Welcome!</h2>

            <!-- Add the button for the post page -->
            <a href="post.php" class="post-button">Post Page</a>

            <!-- Add the button for the profile page -->
            <a href="profile.php" class="profile-button">Profile Page</a>

            <?php

            session_start();

            if (!isset($_SESSION['csrf_token'])) {
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            }

            if(isset($_SESSION["loggedInStatus"]) && $_SESSION["loggedInStatus"] === True){
                echo '<a href="logout.php" class="logout-button">Logout</a>';
            }else {
                echo '<a href="login.php" class="login-button">Login</a>';
            }
            ?>


        </div>
    </div>
</body>
</html>
