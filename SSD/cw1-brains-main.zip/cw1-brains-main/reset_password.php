<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Style for form */ 
        form {
            margin: 0 auto;
            width: 50%;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        /* style for input box */
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<form action="" method="post">
    <input type="password" name="Password" placeholder="Enter your new Password" required>
    <button type="submit">Confirm</button>
</form>

<?php
session_start();

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if(isset($_SESSION['loggedInStatus']) && $_SESSION['loggedInStatus'] === true){
    header("location: index.php");
    exit(); // exit after header redirect
}

$email = $_SESSION['email'];
$newPass;

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $newPass = $_POST['Password'];

    $hash = password_hash($newPass, PASSWORD_DEFAULT);  // and hashes their new password when stored into database.
    // regex for password strength
    $uppercase = preg_match('@[A-Z]@', $newPass);
    $lowercase = preg_match('@[a-z]@', $newPass);
    $number    = preg_match('@[0-9]@', $newPass);
    $specialChars = preg_match('@[^\w]@', $newPass);

    if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($newPass) < 8) {
        echo 'Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.';
    } else {
        echo 'Strong password.';

        $dbcreds = new mysqli('localhost', 'root', '', 'webdb');

        if($stmt = $dbcreds->prepare("UPDATE `users` SET `password` = ? WHERE `email` = ?")){
            $stmt->bind_param("ss", $hash, $email);
            if($stmt->execute()) {
                $stmt->close();
                header("Location: login.php");
                exit(); // exit after header redirect
            } else {
                echo "Database Error! Please Try Again Later!";
            }
        } else {
            echo "Database Error! Please Try Again Later!";
        }
    }
}
?>
</body>
</html>
