<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Style for form */ 
        form {
            margin: 0 auto;
            width: 50%;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<form action="" method="post">
    <input type="text" name="UsersToken" placeholder="Enter the token here." required>
    <button type="submit">Reset Password</button>
</form>

<?php
session_start();

 if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (isset($_SESSION['loggedInStatus']) && $_SESSION['loggedInStatus'] === true) {
    header("location: index.php");
    exit();
}

$email = $_SESSION['email'];
$password = ''; // Initialize password variable

$dbcreds = new mysqli('localhost', 'root', '', 'webdb');

if ($stmt = $dbcreds->prepare("SELECT `password` FROM `users` WHERE `email` = ? LIMIT 1")) {
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($password);
    $stmt->fetch();
    $stmt->close();
} else {
    echo "Database Error! Please Try Again Later!";
}

$issuetime = date("Y-m-d H:i");
$string = $email . $password . $issuetime;  // combines email, password, and date of request into one string
$string_hash = hash("sha256", $string);
const KEY = 'thisismykey';  // key used in encryption variable later on.
$encryption_iv = '1234567890123456';  // ensure the IV vector is not empty hence making it more secure
$msg_encrypted = base64_encode(openssl_encrypt($string_hash, 'aes-128-cbc', KEY, 0, $encryption_iv)); // variable to encrypt the hashed string from earlier
$token_length = strlen($msg_encrypted);
$tokenpart1 = substr($msg_encrypted, 0, 5);
$tokenpart2 = substr($msg_encrypted, $token_length - 3, $token_length);
$token = $tokenpart1 . $tokenpart2;

echo "This is your code: " . $token . "<br>";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_token = $_POST['UsersToken'];
    
    if ($user_token === $token) {
        header("Location: reset_password.php");
        exit();
    } else {
        echo "This is incorrect. Please try again.<br>";
    }
}
?>

</body>
</html>
